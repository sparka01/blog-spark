# Espace Trader Spark

Site HTML statique hébergé avec GitHub Pages.

## 🚀 Déploiement

1. Crée un dépôt GitHub public.
2. Upload les fichiers contenus ici.
3. Active GitHub Pages dans `Settings > Pages > Source: main / root`.
4. Accède à ton site via `https://ton-utilisateur.github.io/espace-trader-spark/`.